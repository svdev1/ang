import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataService } from '../../admin/adminservices/data.service';
import { ActivatedRoute } from '@angular/router'; 
import { UserService } from '../../_services/user.service';
@Component({
  selector: 'app-starter-seller',
  templateUrl: './starter-seller.component.html',
  styleUrls: ['./starter-seller.component.css']
})
export class StarterSellerComponent implements OnInit {
  rForm: FormGroup;
  post:any; 
  public Id : string;
  public agent : any = [];
  public add_form : string = '';
  public edit_form:string = '';
  public uniqueRandom:string='';
  public vUsername:boolean = false;
  public vPersonId:boolean = false;
  public vFirst:boolean = false;
  public vLast:boolean = false;
  public vEmail:boolean = false;
  public vPass:boolean = false;
  public serviceagent:any;
  public usergrp:any;
  public userValidation:any =Array;
  public uiMsg:string='';
  public loading:boolean=false;
  public list_form:string='';

  constructor(private fb: FormBuilder,
              private agentservice: DataService,
              private router: Router,
              private route: ActivatedRoute , 
              private dataService: DataService,
              private userService: UserService) {}

  async ngOnInit() {
    if(this.route.snapshot.params.id == 'add'){
      this.add_form = 'add';
      this.uniqueRandom = this.dataService.guid();
    }else if(this.route.snapshot.params.id != 'add' &&  this.route.snapshot.params.id != 'list'){
      const id: string = this.route.snapshot.params.id;
      this.Id = id;
      this.edit_form = 'edit';
      this.agent = await this.dataService.getHypUserById(this.Id);
    }else if(this.route.snapshot.params.id == 'list'){
      const id: string = this.route.snapshot.params.id;
      this.Id = id;
      this.list_form = 'list';
      this.agent = await this.dataService.getHypUserById(this.Id);
    }
  }

  async addSeller(){
    alert('ADD');
  }

}
